$(function () {
$('[data-toggle="popover"]').popover();
$('div[class*="alert"]').addClass("hidden");
//$('div[class*="alert"]').text("can you dig it");
 })
