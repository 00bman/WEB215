$(function () {
$('[data-toggle="popover"]').popover();
$('div[class*="alert"]').text("can you dig it");
 })
